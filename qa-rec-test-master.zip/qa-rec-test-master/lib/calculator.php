<?php

class calculator {

    public function evaluate($calculation) {
        // Implement this function
    }

}